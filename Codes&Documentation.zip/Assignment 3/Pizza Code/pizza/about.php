<?php
include "header.php";
include "checksession.php";

include "menu.php";
?>
		<div id="body">
			<div class="header">
				<div>
					<h1>About</h1>
				</div>
			</div>
			<div class="body">
				<img src="images/bg-header-about.jpg" alt="About">
			</div>
			<div class="footer">
				<div class="sidebar">
					<h1>Be Part of Our Community</h1>
					<p>If you’re experiencing issues or having concerns about this website template, join the discussion on our <a href="/">facebook page</a> and meet other people in the community who share the same interests.</p>
					<img src="images/calzone_sm.jpg" alt="Calzone Pizza">
				</div>
				<div class="article">
					<h1>We Have Pizzas For Everyone</h1>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean eget lacinia sem. Quisque a libero semper, efficitur ante quis, molestie erat. Phasellus ut turpis libero. Nulla ex est, tristique et nunc id, interdum dignissim nunc. Proin eget ipsum ipsum. Nunc a lectus et neque scelerisque consectetur. Nulla facilisi. </p>
					<p>Nunc consectetur laoreet sodales. Sed posuere eros in arcu vestibulum, sed euismod sem faucibus. Nunc lobortis eleifend enim, ut consequat enim ornare sed. Ut elementum luctus sodales. In venenatis mauris ante, nec aliquam velit eleifend vitae. Curabitur semper, urna eu tincidunt viverra, risus justo egestas ipsum, eget porta ex enim id ante. Integer accumsan libero at nulla scelerisque rhoncus vel luctus tortor. Suspendisse cursus nec lacus lacinia elementum.</p>
					<h1>Who We Are</h1>
					<p>Nunc consectetur laoreet sodales. Sed posuere eros in arcu vestibulum, sed euismod sem faucibus. Nunc lobortis eleifend enim, ut consequat enim ornare sed. Ut elementum luctus sodales. In venenatis mauris ante, nec aliquam velit eleifend vitae. Curabitur semper, urna eu tincidunt viverra, risus justo egestas ipsum, eget porta ex enim id ante. Integer accumsan libero at nulla scelerisque rhoncus vel luctus tortor. Suspendisse cursus nec lacus lacinia elementum.</p>
					<h1>Address</h1>
					<span>Waipukurau Corner Pizzeria</span>
					<span>1 Main Street</span>
					<p>Waipukurau, 4000</p>
					<img src="images/map.png" alt="Pizzeria Map">
				</div>
			</div>
		</div>
<?php
include "footer.php";
?>
