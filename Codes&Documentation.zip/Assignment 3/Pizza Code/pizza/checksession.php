<?php
session_start();
// include 'config.php';
// if (!isset($_SESSION)) { session_start(); }

// overrides for development purposes only - comment this out when testing the login
// $_SESSION['loggedin'] = 0;      
// $_SESSION['customerid'] = 1; //this is the ID for the admin user 
// $_SESSION['email'] = 'Test';
//end of overrides


// var_dump($_SESSION);

function isAdmin() {
 if (($_SESSION['loggedin'] == 1) and ($_SESSION['customerid'] == 1)) 
     return TRUE;
 else 
     return FALSE;
}

//function to check if the user is logged else send to the login page 
function checkUser() {    
    $_SESSION['URI'] = '';    
    if ($_SESSION['loggedin'] == 1)
       return TRUE;
    else {
        // $_SESSION['URI'] = 'http://localhost'.$_SERVER['REQUEST_URI']; //save current url for redirect     
        $_SESSION['URI'] = $_SERVER['REQUEST_URI']; //save current url for redirect     

        header('Location: login.php', true, 303);
    }       
}

//just to show we are are logged in
function loginStatus() {
    if($_SESSION != null && isset($_SESSION['firstname'])){   
        $fn = $_SESSION['firstname'];
        $ln = $_SESSION['lastname'];  
        $email = $_SESSION['email'];
        
        if ($_SESSION['loggedin'] == 1) {  
            echo "<h2>Logged in as $fn $ln</h2>";
        }
        else
            if ($email != '') {  
                $_SESSION['firstname'] = '';
                $_SESSION['lastname'] = ''; 
                $_SESSION['email'] = '';                
                echo "<h2>Logged out</h2>";
            }
    }    
}

//log a user in
function login($id,$email,$fn,$ln) {
   //simple redirect if a user tries to access a page they have not logged in to
   if ($_SESSION['loggedin'] == 0 and !empty($_SESSION['URI']))        
        $uri = $_SESSION['URI'];          
   else { 
     $_SESSION['URI'] = 'listbookings.php'; 
    //  http://localhost/pizza/listcustomers.php';
        
     $uri = $_SESSION['URI'];           
   }  

   $_SESSION['loggedin'] = 1;        
   $_SESSION['customerid'] = $id;
   $_SESSION['email'] = $email;
   $_SESSION['firstname'] = $fn;
   $_SESSION['lastname'] = $ln; 
   $_SESSION['URI'] = ''; 
   header('Location: '.$uri, true, 303);        
}

//simple logout function that clears all of the session variables
function logout(){
  $_SESSION['customerid'] = 0;
  $_SESSION['loggedin'] = 0;
  $_SESSION['customerid'] = -1;
  $_SESSION['email'] = '';
  $_SESSION['firstname'] = '';
  $_SESSION['lastname'] = '';
  $_SESSION['URI'] = '';
  header('Location: login.php', true, 303);    
}
?>