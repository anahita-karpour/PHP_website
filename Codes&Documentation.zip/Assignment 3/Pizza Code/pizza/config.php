<?php
// MySQL credentials - Development Environment
define("DBUSER","root");
define("DBPASSWORD","root");
define("DBDATABASE","pizza");
define("DBHOST","");

//URL Root
// define("WWW_ROOT","http://www.wcpizzeria.unaux.com");

// MySQL credentials - Production Environment
// define("DBUSER","unaux_32656448");
// define("DBPASSWORD","jpp1p7u");
// define("DBDATABASE","unaux_32656448_wcpizzeria");
// define("DBHOST","sql204.unaux.com");

?>