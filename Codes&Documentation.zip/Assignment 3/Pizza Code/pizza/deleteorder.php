<?php
    include "header.php";
    include "checksession.php";
    include "menu.php";
    checkUser();
    ?>
    <div id="body">
        <div class="header">
            <div>
                <h1>Order preview before deletion</h1>
            </div>
        </div>
<?php 
    loginStatus(); 

    include "config.php"; // load in any variables

    $DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE) or die();

    // insert DB code from here onwards
    // check if the connection was good
    if (mysqli_connect_errno()){
        echo "Error: Unable to connect to MySQL. ".mysqli_connect_error();
        exit; // stop processing the page further
    }

    //this line is for debugging purposes so that we can see the actual POST/GET data
    // echo "<pre>"; var_dump($_POST); var_dump($_GET);echo "</pre>";

    // function to clean input but not to validate type and content
    function cleanInput($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    // retrieve the orderID from the URL
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $id = $_GET['id'];
        if (empty($id) or !is_numeric($id)){
            echo "<h2>Invalid orderID</h2>";    // simple error feedback
            exit;
        }
    }

    // the data was sent using a form therefore we use the $_POST instead of $_GET
    // check if we are saving data first by checking if the submit button exists in the array
    if (isset($_POST['submit']) and !empty($_POST['submit']) and ($_POST['submit'] == 'Delete')) {
        $error = 0; //clear our error flag
        $msg = 'Error: ';        

        // orderID (sent via a form it is a string not a number so we try a type convertions!)
        if (isset($_POST['id']) and !empty($_POST['id']) and is_integer(intval($_POST['id']))) {
            $id = cleanInput($_POST['id']);
        } else {
            $error++; // bump the error flag
            $msg .='Invalid order ID';  // append error message
            $id = 0;
        }

        //save the order data if the error flag is still clear and orderID is > 0
        if ($error == 0 and $id > 0) {
            $query1 = "DELETE FROM orderlines WHERE orderID=?";
            $query2 = "DELETE FROM orders WHERE orderID=?";
            
            // 1- Delete the Associated orderlines first
            $stmt1 = mysqli_prepare($DBC,$query1); //prepare the query
            mysqli_stmt_bind_param($stmt1,'i', $id); 
            mysqli_stmt_execute($stmt1);

            // 2- Delete the order last                
            $stmt2 = mysqli_prepare($DBC,$query2); //prepare the query
            mysqli_stmt_bind_param($stmt2,'i', $id); 
            mysqli_stmt_execute($stmt2);

            mysqli_stmt_close($stmt1); 
            mysqli_stmt_close($stmt2);   
            echo "<h2>order details deleted.</h2>";  

            header('refresh:2; url= listorders.php', true, 303);   
            
        } else { 
        echo "<h2>$msg</h2>".PHP_EOL;
        }   
    }

    // prepare a query and send it to the server
    // make sure you prepare queries when creating custom SQL like below
    $query = 'SELECT orders.orderID, orders.orderdate, orders.extra, customer.firstname AS "firstname", customer.lastname AS "lastname", fooditems.pizza as "pizza", 
    fooditems.pizza AS "pizza", orderlines.quantity AS "qty"
    FROM orders 
    INNER JOIN orderlines ON orderlines.orderID = orders.orderID      
    INNER JOIN customer ON customer.customerID = orders.customerID
    INNER JOIN fooditems ON orderlines.itemID = fooditems.itemID
    WHERE orders.orderID = ?'; //WHERE orders.orderID ='.$id;

    $stmt = mysqli_prepare($DBC,$query);    // prepare the query
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);

    //Getting the result
    $result = mysqli_stmt_get_result($stmt);
    // returns the number of rows in a result set
    $rowcount = mysqli_num_rows($result); 
?>
<div class="body">
    <div>
    <h2>
        <a href='listorders.php'>[Return to the Orders listing]</a>
        <a href='index.php'>[Return to the main page]</a>
    </h2>
    <?php
        // a variable to check if the return row of result is the first row
        $isFirst = true;
        // makes sure we have order item
        if ($rowcount > 0 ){
            echo "<fieldset><legend>Pizza order detail for order #$id</legend><dl>";
            while ($row = mysqli_fetch_assoc($result)) { 
                if($isFirst) {
                    echo "<dt>Date & time ordered for:</dt><dd>".$row['orderdate']."</dd>".PHP_EOL;
                    echo "<dt>Customer name:</dt><dd>".$row['lastname']." ".$row['firstname']."</dd>".PHP_EOL;
                    echo "<dt>Extras:</dt><dd>".$row['extra']."</dd>".PHP_EOL;
                    echo "<dt>Pizzas:</dt><dd>".PHP_EOL;
                    echo $row['pizza']." x ".$row['qty'].",".PHP_EOL; 
                } else {
                    echo $row['pizza']." x ".$row['qty'].",".PHP_EOL;        
                }
                $isFirst = false;
            }
            echo "</dd></dl></fieldset>".PHP_EOL;
    ?>
        <form method="POST" action="deleteorder.php">
            <h2>Are you sure you want to delete this order?</h2>
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <input type="submit" name="submit" value="Delete" id="submit">
            <a href="listorders.php">[Cancel]</a>
        </form>
    <?php
    } else echo "<h2>No order item found!</h2>";     // suitable feedback
    mysqli_stmt_free_result($stmt);   // free any memory used by the query 
    mysqli_stmt_close($stmt);
    mysqli_close($DBC);             // close the connection once done

    echo "</div>";
    echo "</div>";
    echo "</div>";
    
    include "footer.php";
    ?>