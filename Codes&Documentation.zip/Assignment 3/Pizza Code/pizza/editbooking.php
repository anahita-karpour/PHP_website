<?php
  include "header.php";
  include "checksession.php";
  include "menu.php";
  checkUser();
  ?>
    <div id="body">
    <div class="header">
        <div>
        <h1>Edit a booking</h1>
        </div>
    </div>
    <?php 
    loginStatus();

    include "config.php";   // load in any variables

    $DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE) or die();

    if (mysqli_connect_errno()) {
        echo "Error: unable to connect to MySQL. " . mysqli_connect_error();
        exit;   // stop processing the page further
    }

    // function to clean input but not validate type and content
    function cleanInput($data)
    {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    // retrieve the bookingID from the URL
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $id = $_GET['id'];
        if (empty($id) or !is_numeric($id)) {
            echo "<h2>Invalid booking ID</h2>";   // simple error feedback
            exit;
        }
    }

    // the data was sent using the form therefore we use the $_POST instead of $_GET
    // check if we are saving data first by checking if the submit button exists in the array
    if (isset($_POST['submit']) and !empty($_POST['submit']) and ($_POST['submit'] == 'Update')) {
        //validate incoming data  
        $error = 0; //clear our error flag
        $msg = 'Error: ';

        //bookingID (sent via a form it is a string not a number so we try a type conversion!)
        if (isset($_POST['id']) and !empty($_POST['id']) and (is_integer(intval($_POST['id'])))) {
            $id = cleanInput($_POST['id']);
        } else {
            $error++;   //bumpt the error flag
            $msg .= 'Invalid booking ID ';    //append error message
            $id = 0;
        }

        //bookingdate
        if (isset($_POST['bookingdate']) and !empty($_POST['bookingdate']) and (is_string($_POST['bookingdate']))) { 
            $bd = cleanInput($_POST['bookingdate']);
            $bookingdate = (strlen($bd) > 19) ? substr($bd, 1, 19) : $bd;  // check length and clip if too big
            // we would also do context checking here for contents, etc
        } else {
            $error++;    // bump the error flag
            $msg .= 'Invalid bookingdate  ';    // append error message
            $extra = '';
        }

        //Telephone            
        if (isset($_POST['telephone']) and !empty($_POST['telephone']) and is_string($_POST['telephone'])) {
            $tel = cleanInput($_POST['telephone']);
            $telephone = (strlen($tel) > 12) ? substr($tel, 1, 12) : $tel;  // check length and clip if too big
        } else {
            $error++;
            $msg .= 'Invalid telephone '; // append error message
            $orderdate = '';
        }

        //People
        if (isset($_POST['people']) and !empty($_POST['people']) and (is_integer(intval($_POST['people'])))) {
            $people = cleanInput($_POST['people']);
        } else {
            $error++;   //bumpt the error flag
            $msg .= 'Invalid people number ';    //append error message
            $people = 0;
        }

        //save the booking data if the error flag is still clear and booking id is > 0
        if ($error == 0 and $id > 0) {

            // Update the booking details
            $query = "UPDATE booking SET booking.bookingdate=?, booking.telephone=?, booking.people=? WHERE booking.bookingID=?";
            $stmt = mysqli_prepare($DBC, $query);    // prepare the query
            mysqli_stmt_bind_param($stmt, 'ssii', $bookingdate, $telephone, $people, $id);
            mysqli_stmt_execute($stmt);
            // mysqli_stmt_free_result($stmt);   // free any memory used by the query
            mysqli_stmt_close($stmt);
            echo "<h2>Booking details updated</h2>";

            //Development Environment
            header('refresh:2; url= listbookings.php', true, 303);
        } else {
            echo "<h2>$msg</h2>" . PHP_EOL;
        }
  }
    // locate the booking to edit by using the bookingID
    // we also include the bookingID in our form for sending it back for saving the data
    $query = 'SELECT bookingID, bookingdate, telephone, people, customer.firstname as "firstname", customer.lastname as "lastname"
        FROM booking 
        INNER JOIN customer ON customer.customerID = booking.customerID
        WHERE booking.bookingID = ?';  

    $stmt = mysqli_prepare($DBC, $query);      // prepare the query
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    // getting the reslt
    $result = mysqli_stmt_get_result($stmt);
    // returns the number of rows in a result set
    $rowcount = mysqli_num_rows($result);

    if ($rowcount > 0) {
        //mysqli_fetch_assoc fetches one row
        $row = mysqli_fetch_assoc($result);
            
    ?>

  <div class="body">
    <div>

  <h2>
    <a href="listbookings.php">[Return to the bookings listing]</a>
    <a href="index.php">[Return to the main page]</a>
  </h2>
  <h2>Booking made for <?php echo $row['firstname'].", ".$row['lastname']; ?></h2>

  <form method="POST" action="editbooking.php">
    <input type="hidden" name="id" value=<?php echo $id;?> />
    <p>
      <label for="bookingdate">Booking date & time: </label>
      <input type="text" id="bookingdate" name="bookingdate" value="<?php echo $row['bookingdate']; ?>" required />
    </p>
    <p>
      <label for="telephone">Contact number: </label>
      <input type="text" id="telephone" name="telephone" value="<?php echo $row['telephone']; ?>" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" required />
    </p>
    <p>
      <label for="people">Party size (# people, 1-10): </label>
      <input type="number" id="people" name="people" min="1" max="10" step="1" value=<?php echo $row['people']; ?> required />
    </p>

    <input type="submit" name="submit" value="Update" id="submit">
    <a href="listbookings.php">[Cancel]</a>
  </form>
  <?php 
} else { 
  echo "<h2>Booking not found with that ID</h2>"; //simple error feedback
}
mysqli_stmt_free_result($stmt);   // free any memory used by the query 
mysqli_stmt_close($stmt);
mysqli_close($DBC); //close the connection once done

echo "</div>";
echo "</div>";
echo "</div>";

include "footer.php";
?>
  <!-- print bookig datetime
  <script>
    var bookingInput = document.getElementById("bookingdate");
    // As a best practice, we do not include the ( ) of the function when setting event handlers in code.
    bookingInput.onchange = printValue;

    function printValue() {
      var x = bookingInput.value;
      console.log(x);
    }
  </script> -->

  <!-- flatpickr -->
  <script>
    config = {
      enableTime: true,
      dateFormat: "Y-m-d H:i:S",
      // altInput: true,
      // altFormat: "Y-m-d H:i",      
      enableSeconds: true,
      allowInput: true,   // prevent "readonly"
      //assuming minimum/earliest date of order can be today
      minDate: "today",
      maxDate: "2023.12.25",
      minTime: "10:00",
      maxTime: "21:00",
    };
    flatpickr("#bookingdate", config);
  </script>