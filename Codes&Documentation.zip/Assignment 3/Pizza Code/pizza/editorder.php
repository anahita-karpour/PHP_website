<!-- Assumptions:
    -orderline:
        -maximum number of pizza for any pizza name is 20.
        -at least one order line is required.
    -orderdate input is a required field.
    -Pizza quantity is added together for duplicated pizza names on orderlines
    -Pizza qty is capped at 20 pizzas per pizza name if multiple orderlines of same pizza name is entered

    -Extra input box:
        -is not a required field and can be null
        -maximum text length of 60 and minimum length of 0 (the value can be null) for Extra input box
        -assuming alphanumeric value for the Extra input box with no white spaces is allowed 
            at the start or end    
 -->
    <?php
    include "header.php";
    include "checksession.php";
    include "menu.php";
    checkUser();
    ?>
    <div id="body">
        <div class="header">
            <div>
                <h1>Order details update</h1>
            </div>
        </div>
<?php 
    loginStatus();

    include "config.php"; // load in any variables
    $DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE) or die();

    if (mysqli_connect_errno()) {
        echo "Error: unable to connect to MySQL. " . mysqli_connect_error();
        exit;   // stop processing the page further
    }

    // function to clean input but not validate type and content
    function cleanInput($data)
    {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    // retrieve the orderID from the URL
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $id = $_GET['id'];
        if (empty($id) or !is_numeric($id)) {
            echo "<h2>Invalid order ID</h2>";   // simple error feedback
            exit;
        }
    }

    // the data was sent using the form therefore we use the $_POST instead of $_GET
    // check if we are saving data first by checking if the submit button exists in the array
    if (isset($_POST['submit']) and !empty($_POST['submit']) and ($_POST['submit'] == 'Update')) {
        //validate incoming data  
        $error = 0; //clear our error flag
        $msg = 'Error: ';

        //orderID (sent via a form it is a string not a number so we try a type conversion!)
        if (isset($_POST['id']) and !empty($_POST['id']) and (is_integer(intval($_POST['id'])))) {
            $id = cleanInput($_POST['id']);
        } else {
            $error++;   //bumpt the error flag
            $msg .= 'Invalid order ID ';    //append error message
            $id = 0;
        }

        //extra
        if (isset($_POST['extra']) and (is_string($_POST['extra']))) { 
            $ex = cleanInput($_POST['extra']);
            $extra = (strlen($ex) > 60) ? substr($ex, 1, 60) : $ex;  // check length and clip if too big
            // we would also do context checking here for contents, etc
        } else {
            $error++;    // bump the error flag
            $msg .= 'Invalid extra  ';    // append error message
            $extra = '';
        }

        //orderdate            
        if (isset($_POST['orderdate']) and !empty($_POST['orderdate']) and is_string($_POST['orderdate'])) {
            $od = cleanInput($_POST['orderdate']);
            $orderdate = (strlen($od) > 19) ? substr($od, 1, 19) : $od;  // check length and clip if too big
        } else {
            $error++;
            $msg .= 'Invalid orderdate '; // append error message
            $orderdate = '';
        }

        // orderline pizza
        $pizzas = [];
        foreach ($_POST['pizza'] as $pizz) {
            if (isset($pizz) and !empty($pizz) and is_integer(intval($pizz))) {
                $pizza = cleanInput($pizz);
                $pizzas[] = $pizza;
            } else {
                $error++;       // bump the error flag
                $msg .= 'Invalid pizza name '; //append error message
                $pizza = '';
            }
        }

        // orderline quantity
        $qtys = [];
        foreach ($_POST['qty'] as $qt) {
            if (isset($qt) and !empty($qt) and is_integer(intval($qt))) {
                $qty = cleanInput($qt);
                if ($qty < 1 or $qty > 20) $qty = 1;
                $qtys[] = $qty;
            } else {
                $error++;   // bump the error flag
                $msg .= 'Invalid pizza quantity! ';
                $qty = '';
            }
        }

        // combine the pizza and pizza qty arrays into one.
        // ensuring quantity is added for duplicated keys, pizza qty is capped at 20 pizzas per pizza name!
        $orderlines = array_unique($pizzas);
        $orderlines = array_fill_keys($orderlines, 0);

        foreach ($pizzas as $k => $v) {
            if ($orderlines[$v] < 21 && ($orderlines[$v] + $qtys[$k]) < 21) {
                $orderlines[$v] += $qtys[$k];
            } else {
                // enforcing 20 pizza per pizza name                
                $orderlines[$v] = 20;   
            }
        }

        //save the order data if the error flag is still clear and order id is > 0
        if ($error == 0 and $id > 0) {

            // 1-delete all orderlines of the selected orderID
            $query = "DELETE FROM orderlines WHERE orderlines.orderID=?";
            $stmt = mysqli_prepare($DBC, $query);    // prepare the query
            mysqli_stmt_bind_param($stmt, 'i', $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);

            // 2-insert the new orderlines
            $query = "INSERT INTO orderlines (orderlines.orderID, orderlines.itemID, orderlines.quantity) VALUES (?,?,?);";
            foreach ($orderlines as $key => $value) {
                $stmt = mysqli_prepare($DBC, $query);
                // adding orderID, pizza name, pizza qty
                mysqli_stmt_bind_param($stmt, 'iis', $id, $key, $value);
                mysqli_stmt_execute($stmt);
            }
            mysqli_stmt_close($stmt);

            // 3-Update the extra and orderdate
            $query = "UPDATE orders SET orders.orderdate=?, orders.extra=? WHERE orders.orderID=?";
            $stmt = mysqli_prepare($DBC, $query);    // prepare the query
            mysqli_stmt_bind_param($stmt, 'ssi', $orderdate, $extra, $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            echo "<h2>Order details updated</h2>";
            //Development Environment
            header('refresh:2; url= listorders.php', true, 303);
        } else {
            echo "<h2>$msg</h2>" . PHP_EOL;
        }
    }

    // dynamic populating
    // populate the pizza dropdown menu
    $query = 'SELECT fooditems.itemID AS "pizzaNo", fooditems.pizza AS "pizza", fooditems.price 
        FROM fooditems';

    $stmt = mysqli_prepare($DBC, $query);      // prepare the query
    mysqli_stmt_execute($stmt);
    // getting the reslt
    $result = mysqli_stmt_get_result($stmt);
    // returns the number of rows in a result set
    $rowcount = mysqli_num_rows($result);

    // locate the order to edit by using the orderID
    // we also include the orderID in our form for sending it back for saving the data
    $query2 = 'SELECT orders.orderID, orders.orderdate AS "orderdate", orders.extra AS "extra", fooditems.pizza AS "pizza", fooditems.price AS "price", 
        orderlines.quantity AS "qty", customer.firstname AS "firstname", customer.lastname AS "lastname"
        FROM orders
        INNER JOIN customer ON customer.customerID = orders.customerID
        INNER JOIN orderlines ON orderlines.orderID = orders.orderID   
        INNER JOIN fooditems ON orderlines.itemID = fooditems.itemID
        WHERE orders.orderID = ?';  

    $stmt2 = mysqli_prepare($DBC, $query2);      // prepare the query
    mysqli_stmt_bind_param($stmt2, 'i', $id);
    mysqli_stmt_execute($stmt2);
    // getting the reslt
    $result2 = mysqli_stmt_get_result($stmt2);
    // returns the number of rows in a result set
    $rowcount2 = mysqli_num_rows($result2);

    // a variable to check if the return row of result is the first row
    $isFirst = true;
    // counter for setting pizza input elements ID
    $pizzaID = 1;
    $html = "";
    if ($rowcount2 > 0) {
        //mysqli_fetch_assoc fetches one row
        while ($row2 = mysqli_fetch_assoc($result2)) {
            if ($isFirst) {
    ?>
                <div class="body">
                    <div>
                <h2>
                    <a href="listorders.php">[Return to the Orders listing]</a>
                    <a href="index.php">[Return to the main page]</a>
                </h2>
                <h2>Pizza order for customer <?php echo ($row2['firstname']. " " .$row2['lastname']); ?></h2>

                <form method="POST" id="editorderfrm" action="editorder.php">
                    <input type="hidden" name="id" value="<?php echo $id; ?>" />
                    <p>
                        <label for="orderdate">Order for (date & time): </label>
                        <input type="text" id="orderdate" name="orderdate" value="<?php echo $row2['orderdate'] ?>" required />
                    </p>
                    <p>
                        <label for="extra">Extras:</label>
                        <input type="text" id="extra" name="extra" value="<?php echo $row2['extra'] ?>" maxlength="60" size="50" pattern="^[a-zA-Z0-9].[a-zA-Z0-9_\s-]*[a-zA-Z0-9]$" />
                    </p>
                    <hr />
                    <table id="tblOrderlines">
                        <thead>
                            <tr>
                                <th colspan="3">Pizzas for this order:</th>
                            </tr>
                        </thead>
                        <tbody>
            <?php
            }
            ?>
                        <tr>
                            <td>
                                <label for="pizza<?php echo $pizzaID ?>"><b><?php echo $pizzaID ?>:</b></label>
                            </td>
                            <td>
                                <select name="pizza[]" id="pizza<?php echo $pizzaID ?>" required>
                                    <option value="">none</option>

                                    <?php
                                    if ($rowcount > 0) {
                                        $selected = '';
                                        foreach ($result as $row) {
                                            $selected = ($row2['pizza'] == $row['pizza']) ? $row['pizza'] : '';
                                            $html .= "<option value =" . $row['pizzaNo'];
                                            if ($selected == $row['pizza']) {
                                                $html .= ' selected="selected"';
                                            } else {
                                                $html .= '';
                                            }
                                            $html .= ">" . $row['pizza'] . " @ $" . $row['price'] . "</option>";
                                            echo $html;
                                            $html = '';
                                        }
                                    ?>
                                        <?php echo $pizzaID ?>
                                <?php
                                    } else {
                                        $html = "<h2>Pizza items not found</h2>";
                                    }                                     
                                    $selected = $row2['pizza'];                              
                                    ?>
                                </select>
                            </td>
                            <td>
                                <input type="number" id="qty<?php echo $pizzaID ?>" name="qty[]" min="1" max="20" step="1" value="<?php echo $row2['qty'] ?>" placeholder="0" class="quantity" required />
                            </td>
                            <td>
                            <?php
                            if ($isFirst) {
                                echo '<input type="button" name="add" value="Add Pizza" onclick="addPizza()" id="submit" />';
                            } else {
                                echo '<input type="button" name="delete" value="Delete" onclick="deleteRow(this)" id="submit" />';
                            }

                            $isFirst = false;
                            // increment and set the id again
                            $pizzaID = ++$pizzaID;
                        }
                            ?>
                            </td>
                        </tr>

                        </tbody>
                    </table>
                    <input type="submit" name="submit" value="Update" id="submit"/>
                    <a href="listorders.php">[Cancel]</a>
                </form>
            <?php
        } else {
            echo "<h2>order not found with that ID</h2>"; // simple error feedback
        }

        mysqli_stmt_free_result($stmt);   // free any memory used by the query
        mysqli_stmt_close($stmt);

        mysqli_stmt_free_result($stmt2);   // free any memory used by the query
        mysqli_stmt_close($stmt2);
        mysqli_close($DBC);             // close the connection once done

        echo "</div>";
        echo "</div>";
        echo "</div>";
        include "footer.php";
    ?>

        <!-- flatpickr -->
        <script>
            config = {
                enableTime: true,
                dateFormat: "Y-m-d H:i:S",
                altInput: true,
                altFormat: "Y-m-d H:i",
                allowInput: true, //prevent "readonly"
                //assuming minimum/earliest date of order can be today
                minDate: "today",
                maxDate: "2023.12.25",
                minTime: "10:00",
                maxTime: "21:00",
            };
            flatpickr("#orderdate", config);
        </script>
    