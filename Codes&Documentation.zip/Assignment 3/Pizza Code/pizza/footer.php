
		</div>		
<!-- footer start -->        
        <div id="footer">
			<div>
				<div class="connect">
					<a href="http://freewebsitetemplates.com/go/facebook/" class="facebook">facebook</a>
					<a href="http://freewebsitetemplates.com/go/twitter/" class="twitter">twitter</a>
					<a href="http://freewebsitetemplates.com/go/googleplus/" class="googleplus">googleplus</a>
					<a href="http://pinterest.com/fwtemplates/" class="pinterest">pinterest</a>
				</div>
				<p>&copy; <?php echo date('Y'); ?> Waipukurau Corner Pizzeria. All Rights Reserved.</p>
			</div>
		</div>
	</div>
<!-- footer end -->    
</body>
</html>
