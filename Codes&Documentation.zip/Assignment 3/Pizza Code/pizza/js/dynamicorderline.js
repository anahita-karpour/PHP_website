    var pizzaID = 2;
    
    function addPizza() {
      // console.log("Add button was pressed");
      var tbl = document.getElementById("tblOrderlines");
      var rowCount = tbl.rows.length;

      // line number HTML element
      var lineNumber = '<label><b>' + rowCount + ':<\/b><\/label>';

      // pizza option HTML element
      var selectPizza = tbl.rows[1].cells[1].innerHTML;

      // pizza Qty HTML element
      var qtyPizza = tbl.rows[1].cells[2].innerHTML;

      // delete Btn HTML element
      var deleteBtn = '<input type="button" name="delete" value="Delete" onclick="deleteRow(this)" id="submit"/>'

      var newRow = tbl.insertRow(-1);

      //line number
      var newCell = newRow.insertCell(-1);
      newCell.innerHTML = lineNumber;
      newCell.firstElementChild.setAttribute("id", "pizzalbl"+ pizzaID);
      newCell.firstElementChild.setAttribute("for", "pizza"+ pizzaID);

      //pizza option
      var newCell = newRow.insertCell(-1);
      newCell.innerHTML = selectPizza;
      newCell.firstElementChild.setAttribute("id", "pizza"+ pizzaID);
      newCell.firstElementChild.value = "";

      //pizza Qty
      var newCell = newRow.insertCell(-1);
      newCell.innerHTML = qtyPizza;
      newCell.firstElementChild.setAttribute("id", "qty"+ pizzaID);
      newCell.firstElementChild.placeholder = 0;

      //delete Btn
      var newCell = newRow.insertCell(-1);
      newCell.innerHTML = deleteBtn;

      ++pizzaID;
    }

    function deleteRow(r) {
      //find the table in the HTML
      var tbl = document.getElementById("tblOrderlines");

      // console.log("Delete button was pressed");
      // get the index of the row to be deleted
      var i = r.parentNode.parentNode.rowIndex;
      tbl.deleteRow(i);

      // reset the order line number
      var rowCount = tbl.rows.length - 1;
      for (var i = 2; i < rowCount + 1; i++) {
        tbl.rows[i].cells[0].childNodes[0].innerHTML = "<b>" + i + ":<\/b>";
      }
    }