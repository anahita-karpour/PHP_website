<?php 
include "header.php";
include "checksession.php";
include "menu.php";
checkUser();
?>
  <div id="body">
      <div class="header">
          <div>
          <h1>Customer Detail List</h1>
          </div>
      </div>
  <?php 
loginStatus();
!isAdmin()? "": header('Location: listcustomers.php', true, 303);

if(!isAdmin()){
  include "config.php"; //load in any variables
  
  $DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE) or die();
  
  if (mysqli_connect_errno()) {
      echo "Error: Unable to connect to MySQL. ".mysqli_connect_error() ;
      exit;
  }
  
  $id = $_SESSION["customerid"];
  $query =  "SELECT customerID,firstname,lastname FROM customer WHERE customerID = ".$id;
  $result = mysqli_query($DBC,$query);
  $rowcount = mysqli_num_rows($result); 
  /* turnoff PHP to use some HTML - this quicker to do than php echos,
    we have an example of embedding php in small parts – see member count below
*/
?>
<div class="body">
  <div>
<h2><a href="index.php">[Return to main page]</a>
</h2>
<table id="tblcustomers" border="1">
<thead><tr><th>Lastname</th><th>Firstname</th><th>actions</th></tr></thead>

<?php

  //makes sure we have members
  if ($rowcount > 0) {  
      while ($row = mysqli_fetch_assoc($result)) {
      $id = $row['customerID'];	
      echo '<tr><td>'.$row['lastname'].'</td><td>'.$row['firstname'].'</td>';
      echo '<td><a href="viewcustomer.php?id='.$id.'">[view]</a>';
      echo '<a href="editcustomer.php?id='.$id.'">[edit]</a>';
      echo '</tr>'.PHP_EOL;
    }
  } else echo "<h2>No member found!</h2>"; //suitable feedback
  
  mysqli_free_result($result); 
  mysqli_close($DBC);

  echo "</table>";
  echo "</div>";
  echo "</div>";
}
echo "</div>";

  include "footer.php";
?>