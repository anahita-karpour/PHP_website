<?php 
  include "header.php";
  include "checksession.php";
  include "menu.php";
  
  checkUser();
  ?>
  <div id="body">
      <div class="header">
          <div>
          <h1>Customer List Search by Lastname</h1>
          </div>
      </div>
  <?php 
  loginStatus();
  isAdmin()? "": header('Location: listcustomer.php', true, 303);
?>
<script>

function searchResult(searchstr) {
  if (searchstr.length==0) {

    return;
  }
  // XMLHttpRequest(XHR) objects are used to interact with servers. 
  // You can retrieve data from a URL without having to do a full page refresh. 
  // This enables a Web page to update just part of a page without disrupting what the user is doing.

  // In the first line we create an XMLHttpRequest object
  xmlhttp=new XMLHttpRequest();
  // The onreadystatechange property specifies a function to be executed every time the status of the XMLHttpRequest object changes:
  xmlhttp.onreadystatechange=function() {
    // XMLHttpRequest(XHR).readyState returns a number representing the state of the request
    // When readyState property is 4 and the status property is 200, the response is ready
    if (this.readyState==4 && this.status==200) {
    // // The responseText property returns the server response as a text string.

    //take JSON text from the server and convert it to JavaScript objects
    //mbrs will become a two dimensional array of our customers much like 
    //a PHP associative array
      var mbrs = JSON.parse(this.responseText);  //deserialise the JSON            
      var tbl = document.getElementById("tblcustomers"); //find the table in the HTML
      
      //clear any existing rows from any previous searches
      //if this is not cleared rows will just keep being added
      var rowCount = tbl.rows.length;
      for (var i = 1; i < rowCount; i++) {
         //delete from the top - row 0 is the table header we keep
         tbl.deleteRow(1); 
      }      
      
      //populate the table
      //mbrs.length is the size of our array
      for (var i = 0; i < mbrs.length; i++) {
         var mbrid = mbrs[i]['customerID'];
         var fn    = mbrs[i]['firstname'];
         var ln    = mbrs[i]['lastname'];
      
         //concatenate our actions urls into a single string
         var urls  = '<a href="viewcustomer.php?id='+mbrid+'">[view]</a>';
             urls += '<a href="editcustomer.php?id='+mbrid+'">[edit]</a>';
             urls += '<a href="deletecustomer.php?id='+mbrid+'">[delete]</a>';
         
         //create a table row with three cells  
         tr = tbl.insertRow(-1);
         var tabCell = tr.insertCell(-1);
             tabCell.innerHTML = ln; //lastname
         var tabCell = tr.insertCell(-1);
             tabCell.innerHTML = fn; //firstname      
         var tabCell = tr.insertCell(-1);
             tabCell.innerHTML = urls; //action URLS            
        }
    }
  }
  // Initializes a request
  // call our php file that will look for a customer or customers matchign the seachstring
  xmlhttp.open("GET","customersearch.php?sq="+searchstr,true);
  // Sends the request
  xmlhttp.send();
}
</script>
</head>
<body>

<div class="body">
  <div>
<h2><a href='addcustomer.php'>[Create new Customer]</a><a href="index.php">[Return to main page]</a>
</h2>
<form>
  <label for="lastname">Lastname: </label>
  <input id="lastname" type="text" size="30" 
         onkeyup="searchResult(this.value)" 
         onclick="javascript: this.value = ''" 
         placeholder="Start typing a last name">

</form>
<table id="tblcustomers" border="1">
<thead><tr><th>Lastname</th><th>Firstname</th><th>actions</th></tr></thead>
</table>
</div>
</div>
</div>

<?php
include "footer.php";
?>