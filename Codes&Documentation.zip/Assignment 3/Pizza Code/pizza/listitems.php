<?php
include "header.php";
include "checksession.php";
include "menu.php";
checkUser();
?>
    <div id="body">
        <div class="header">
            <div>
            <h1>Food item list</h1>
            </div>
        </div>
    <?php 
    loginStatus(); 
    isAdmin()? "": header('Location: product.php', true, 303);
    
    include "config.php"; //load in any variables

    $DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE) or die();

    //insert DB code from here onwards
    //check if the connection was good
    if (mysqli_connect_errno()) {
        echo "Error: Unable to connect to MySQL. ".mysqli_connect_error() ;
        exit; //stop processing the page further
    }

    //prepare a query and send it to the server
    $query = 'SELECT itemID,pizza,pizzatype FROM fooditems ORDER BY pizzatype';
    $stmt = mysqli_prepare($DBC, $query);    // prepare the query
    mysqli_stmt_execute($stmt);

    //Getting the result
    $result = mysqli_stmt_get_result($stmt);
    // returns the number of rows in a result set
    $rowcount = mysqli_num_rows($result); 
?>
<div class="body">
    <div>
<h2><a href='additem.php'>[Add a food item]</a><a href="index.php">[Return to main page]</a></h2>
<!-- /pizza/ -->
<table border="1">
<thead><tr><th>Food Item Name</th><th>Type</th><th>Action</th></tr></thead>
<?php

//makes sure we have food items
if ($rowcount > 0) {  
    while ($row = mysqli_fetch_assoc($result)) {
	  $id = $row['itemID'];	
      $pt = $row['pizzatype']=='S'?'Standard':'Vegeterian';
	  echo '<tr><td>'.$row['pizza'].'</td><td>'.$pt.'</td>';
	  echo     '<td><a href="viewitem.php?id='.$id.'">[view]</a>';
	  echo         '<a href="edititem.php?id='.$id.'">[edit]</a>';
	  echo         '<a href="deleteitem.php?id='.$id.'">[delete]</a></td>';
      echo '</tr>'.PHP_EOL;
   }
} else echo "<h2>No food items found!</h2>"; //suitable feedback

mysqli_stmt_free_result($stmt);   // free any memory used by the query
mysqli_stmt_close($stmt);
mysqli_close($DBC);             // close the connection once done

echo "</table>";
echo "</div>";
echo "</div>";
echo "</div>";

include "footer.php";
?>