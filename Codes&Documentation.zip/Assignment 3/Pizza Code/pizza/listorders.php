<?php
    include "header.php";
    include "checksession.php";
    include "menu.php";
    checkUser();
    ?>
    <div id="body">
        <div class="header">
            <div>
                <h1>Current Orders</h1>
            </div>
        </div>
<?php 
    loginStatus();

    include "config.php"; //load in any variables

    $DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE) or die();

    // insert DB code from here onwards
    // check if the connection was good
    if (mysqli_connect_errno()) {
        echo "Error: Unable to connect to MySQL. " . mysqli_connect_error();
        exit; // stop processing the page further
    }
    //this line is for debugging purposes so that we can see the actual POST/GET data
    // echo "<pre>"; var_dump($_POST); var_dump($_GET); var_dump($_SESSION);echo "</pre>";

    // prepare a query and send it to the server
    if (isAdmin()) {
        $query =
            'SELECT orders.orderID, orders.orderdate, customer.firstname AS "firstname", customer.lastname AS "lastname" 
        FROM orders, customer WHERE orders.customerID = customer.customerID ORDER BY orders.orderdate desc';
        
        $stmt = mysqli_prepare($DBC, $query);    // prepare the query

    } else {
        $query =
            'SELECT orders.orderID, orders.orderdate, customer.firstname AS "firstname", customer.lastname AS "lastname"
        FROM orders, customer WHERE orders.customerID = customer.customerID AND customer.customerID = ? ORDER BY orders.orderdate desc';
        // FROM orders, customer WHERE orders.customerID = customer.customerID AND customer.customerID = ' . $_SESSION["customerid"] . ' ORDER BY orders.orderdate desc';
        $cid = $_SESSION["customerid"];
        //a simple validation to check id exists
        if (empty($cid) or !is_numeric($cid)) {
            echo "<h2>Invalid memberID</h2>"; //simple error feedback
            exit;
        } 

        $stmt = mysqli_prepare($DBC, $query);    // prepare the query
        mysqli_stmt_bind_param($stmt, 'i', $cid);
    }
    mysqli_stmt_execute($stmt);

    //Getting the result
    $result = mysqli_stmt_get_result($stmt);
    // returns the number of rows in a result set
    $rowcount = mysqli_num_rows($result);

    ?>
    <div class="body">
        <div>
    <h2>
        <!-- <a href='placeOrderEnhanced.php'>[Place an order]</a> -->
        <a href='placeorderenhanced.php'>[Place an order]</a>
        <a href='index.php'>[Return to the main page]</a>
    </h2>
    <table border="1">
        <thead>
            <tr>
                <th>Orders (Date of order, Order number)</th>
                <th>Customer</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            //set the timezone
            $timezone = date_default_timezone_set('Pacific/Auckland');

            // make sure we have order items
            if ($rowcount > 0) {
                //output data of each row
                while ($row = mysqli_fetch_assoc($result)) {
                    $id = $row['orderID'];
                    $od = $row['orderdate'];
                    $fn = $row['firstname'];
                    $ln = $row['lastname'];
                    echo "<tr><td> $od ($id)</td><td>$ln $fn</td>";
                    echo '<td><a href="vieworder.php?id=' . $id . '">[view]</a>';

                    if ($od > date("Y-m-d h:i:s")) {
                        echo '<a href="editorder.php?id=' . $id . '">[edit]</a>';
                        echo '<a href="deleteorder.php?id=' . $id . '">[delete]</a></td>';
                    } else {
                        echo '[edit]';
                        echo '[delete]</td>';
                    }
                    echo '</tr>' . PHP_EOL;
                }
                // echo date("Y-m-d h:i:s");
            } else echo "<h2>No order items found!</h2>";

            mysqli_stmt_free_result($stmt);   // free any memory used by the query
            mysqli_stmt_close($stmt);
            mysqli_close($DBC);             // close the connection once done

            echo "</tbody>";
            echo "</table>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
            include "footer.php";
            ?>