<?php
include "header.php";
include "checksession.php";
include "menu.php";
?>
<div id="body">
  <div class="header">
    <div>
      <?php
      $login = false;
        if (!isset($_SESSION['loggedin'])) {
          //login
          echo "<h1>Login</h1>";
        } elseif (isset($_SESSION['loggedin'])) {
            if($_SESSION['loggedin'] == 0) {
              //login
              echo "<h1>Login</h1>";
            } elseif($_SESSION['loggedin'] == 1) {
              //logout
              echo "<h1>Logout</h1>";
              $login = true;
            }
        }
      ?>
      <!-- <h1>Login</h1> -->
    </div>
  </div>
<?php 
  loginStatus();
//simple logout
if (isset($_POST['logout'])) logout();
 
if (isset($_POST['login']) and !empty($_POST['login']) and ($_POST['login'] == 'Login')) {
    include "config.php"; //load in any variables
    //Development environment
    // $DBC = mysqli_connect("127.0.0.1", DBUSER, DBPASSWORD, DBDATABASE) or die();
    //Production environment
    $DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE) or die();
 
    //validate incoming data - only the first field is done for you in this example - rest is up to you to do
    //firstname
    $error = 0; //clear our error flag
    $msg = 'Error: ';
    if (isset($_POST['email']) and !empty($_POST['email']) and filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
      $un = htmlspecialchars(stripslashes(trim($_POST['email'])));
      $username = (strlen($un)>100)?substr($un,1,100):$un; //check length and clip if too big       
    } else {
       $error++; //bump the error flag
       $msg .= 'Invalid email '; //append error message
       $username = '';  
    } 
                    
    //password  - normally we avoid altering a password apart from whitespace on the ends
    if (isset($_POST['password']) and !empty($_POST['password'])) {
      $pass = trim($_POST['password']);
      $password = (strlen($pass)>40)?substr($pass,1,40):$pass; //check length and clip if too big
    } else {
      $error++; //bump the error flag
      $msg .= 'Invalid password '; //append error message
      $password = '';  
   } 
               
    if ($error == 0) {
        $query = "SELECT customerID, password, lastname, firstname, email FROM customer WHERE email = ?";
        $stmt = mysqli_prepare($DBC, $query);
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);

        //getting the result
        $result = mysqli_stmt_get_result($stmt);
        //return the number of rows in a result set
        $rowcount = mysqli_num_rows($result);
        // $rowcount = mysqli_stmt_num_rows($stmt);

        if ($rowcount == 1) { //found the user
            $row = mysqli_fetch_assoc($result);
            mysqli_stmt_free_result($stmt);
            mysqli_stmt_close($stmt);
            mysqli_close($DBC); //close the connection once done
            
            //this line would be added to the registermember.php to make a password hash before storing it
            //$hash = password_hash($password); 
            //this line would be used if our user password was stored as a hashed password
           //if (password_verify($password, $row['password'])) {           
            if ($password === $row['password']) //using plaintext            
              login($row['customerID'],$row['email'],$row['firstname'],$row['lastname'], $row['customerID']);
        } echo "<h2>Login fail</h2>".PHP_EOL;   
    } else { 
      echo "<h2>$msg</h2>".PHP_EOL;
    }      
}
?>
  <div class="body">
    <div>
    <form method="POST" action="login.php">
      <p>
        <label for="email">Email: </label>
        <input type="text" id="email" name="email" maxlength="100" size = "50"> 
      </p>  
      <p>
        <label for="password">Password: </label>
        <input type="password" id="password" name="password" minlength ="8" maxlength="40"> 
      </p> 
      
      <input type="submit" name="login" value="Login" <?php if ($login == true){ ?> disabled <?php   } ?>id="submit">
      <input type="submit" name="logout" value="Logout" <?php if ($login == false){ ?> disabled <?php   } ?>id="submit"> 
    </form>
    </div>
  </div>
</div>

<?php 
  include "footer.php";
?>