<!-- menu start -->
        <div id="header">
			<div>
				<a href="index.php" class="logo"><img src="images/logo.png" alt=""></a>
				<ul id="navigation">
					<li class="menu selected">
						<a href="index.php">Home</a>
					</li>
   				    <li class="menu">
						<a href="product.php">Pizzas</a>
						<ul class="primary">
	 						<li><a href="product.php">Pizza Menu</a></li>
	 						<li><a href="placeorderenhanced.php">Place Order</a></li>
						</ul>
                        
					</li>                    
					<li class="menu">
						<a href="about.php">About</a>
						<ul class="primary">
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="contact.php">Contact Us</a></li>
                            <!-- <li><a href="">Terms of Use</a></li> -->
                            <li><a href="privacy.php">Privacy Policy</a></li>
						</ul>
					</li>
					<li class="menu">
						<?php 
						if (!isset($_SESSION['loggedin'])) {
							// echo "<pre>";
							// echo "Loggedin not set";
							// echo "</pre>";
						?>
						<a href="login.php">Login</a>
						<ul class="secondary">
							<li>
                                <a href="placeorderenhanced.php">Sign in to Order</a>
                                <a href="addcustomer.php">Register</a>                                
							</li>
						</ul>
						<?php 
						} elseif (isset($_SESSION['loggedin'])) {
							if($_SESSION['loggedin'] == 0) {
						?>
						<a href="login.php">Login</a>
						<ul class="secondary">
							<li>
                                <a href="placeorderenhanced.php">Sign in to Order</a>
                                <a href="addcustomer.php">Register</a>                                
							</li>
						</ul> 
						<?php } elseif($_SESSION['loggedin'] == 1) {
							?>
							<a href="login.php">Logout</a>
						<?php }
						}
						?>                       
					</li>
					<li class="menu">
						<?php 
						if(!isset($_SESSION['loggedin'])) {
						?>
							<a href='login.php'>Account</a>
						<?php 
						} elseif(isset($_SESSION['loggedin'])) {
							if($_SESSION['loggedin'] ==0) {
							?>
								<a href='login.php'>Account</a>
							<?php 	
							} elseif (isset($_SESSION['loggedin'])) {
								if(isAdmin()){
						?>
							<a href='listbookings.php'>Admin</a>						 
								<ul class="secondary">
									<li><a href="listbookings.php">Reservations</a></li>
									<li><a href="listorders.php">Orders</a></li>
									<li><a href="listitems.php">Products</a></li>                            
									<li><a href="listcustomers.php">Customers</a></li>                                                        
								</ul>
					<?php
							} elseif(!isAdmin()) {
					?>
								<a href='listbookings.php'>Customer</a>						 
								<ul class="secondary">
									<li><a href="listbookings.php">Reservations</a></li>
									<li><a href="listorders.php">Orders</a></li>
									<li><a href="product.php">Products</a></li>                            
									<li><a href="listcustomer.php">Customer Info</a></li>                                                        
								</ul>					
					<?php
							}
						}
					}
					?>
					</li>
				</ul>
			</div>
		</div>
<!-- menu end -->