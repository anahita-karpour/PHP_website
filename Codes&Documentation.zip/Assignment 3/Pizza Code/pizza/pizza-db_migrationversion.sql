-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 24, 2022 at 03:55 AM
-- Server version: 8.0.29
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pizza`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `bookingID` int UNSIGNED NOT NULL,
  `customerID` int UNSIGNED NOT NULL,
  `telephone` varchar(14) NOT NULL,
  `bookingdate` datetime DEFAULT NULL,
  `people` int DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`bookingID`, `customerID`, `telephone`, `bookingdate`, `people`) VALUES
(1, 1, '592-232-0521', '2022-12-18 17:29:36', 2),
(2, 8, '775-120-6785', '2023-05-18 06:13:06', 4),
(3, 4, '393-916-0672', '2022-02-11 08:39:29', 1),
(4, 9, '114-541-0005', '2022-11-28 12:20:58', 1),
(5, 2, '561-687-0825', '2021-06-10 03:52:37', 4),
(6, 9, '959-512-2639', '2021-03-24 17:06:28', 3),
(7, 2, '593-781-9360', '2023-03-01 04:11:27', 4),
(8, 7, '473-595-2768', '2022-11-04 08:16:06', 5),
(9, 4, '673-132-5499', '2023-01-29 16:57:48', 3),
(10, 1, '151-149-9447', '2023-05-20 14:13:23', 2),
(11, 4, '382-125-5641', '2023-01-16 17:42:15', 5),
(12, 7, '507-644-2363', '2023-03-24 05:13:46', 3);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerID` int UNSIGNED NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL DEFAULT '.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerID`, `firstname`, `lastname`, `email`, `password`) VALUES
(1, 'Admin', 'Admin', 'admin@pizza.com', 'password'),
(2, 'Desiree', 'Collier', 'Maecenas@non.co.uk', '.'),
(3, 'Irene', 'Walker', 'id.erat.Etiam@id.org', '.'),
(4, 'Forrest', 'Baldwin', 'f.baldwin@a.com', 'password'),
(5, 'Beverly', 'Sellers', 'ultricies.sem@pharetraQuisqueac.co.uk', '.'),
(6, 'Glenna', 'Kinney', 'dolor@orcilobortisaugue.org', '.'),
(7, 'Montana', 'Gallagher', 'sapien.cursus@ultriciesdignissimlacus.edu', '.'),
(8, 'Harlan', 'Lara', 'Duis@aliquetodioEtiam.edu', '.'),
(9, 'Benjamin', 'King', 'mollis@Nullainterdum.org', '.'),
(10, 'Rajah', 'Olsen', 'Vestibulum.ut.eros@nequevenenatislacus.ca', '.'),
(11, 'Castor', 'Kelly', 'Fusce.feugiat.Lorem@porta.co.uk', '.'),
(12, 'Omar', 'Oconnor', 'eu.turpis@auctorvelit.co.uk', '.'),
(13, 'Porter', 'Leonard', 'dui.Fusce@accumsanlaoreet.net', '.'),
(14, 'Buckminster', 'Gaines', 'convallis.convallis.dolor@ligula.co.uk', '.'),
(15, 'Hunter', 'Rodriquez', 'ridiculus.mus.Donec@est.co.uk', '.'),
(16, 'Zahir', 'Harper', 'vel@estNunc.com', '.'),
(17, 'Sopoline', 'Warner', 'vestibulum.nec.euismod@sitamet.co.uk', '.'),
(18, 'Burton', 'Parrish', 'consequat.nec.mollis@nequenonquam.org', '.'),
(19, 'Abbot', 'Rose', 'non@et.ca', '.'),
(20, 'Barry', 'Burks', 'risus@libero.net', '.');

-- --------------------------------------------------------

--
-- Table structure for table `fooditems`
--

CREATE TABLE `fooditems` (
  `itemID` int UNSIGNED NOT NULL,
  `pizza` varchar(15) NOT NULL,
  `description` text,
  `pizzatype` char(1) DEFAULT 'S',
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `fooditems`
--

INSERT INTO `fooditems` (`itemID`, `pizza`, `description`, `pizzatype`, `price`) VALUES
(1, 'PIZZA 1', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur sed tortor. Integer aliquam adipiscing', 'S', 10),
(2, 'PIZZA 2', 'Lorem ipsum dolor sit amet, consectetuer', 'S', 10),
(3, 'PIZZA 3', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur', 'S', 6),
(4, 'PIZZA 4', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur sed tortor. Integer aliquam', 'S', 6),
(5, 'PIZZA 5', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur sed tortor. Integer aliquam adipiscing lacus.', 'S', 8),
(6, 'PIZZA 6', 'Lorem ipsum dolor sit amet, consectetuer adipiscing', 'S', 7),
(7, 'PIZZA 7', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur sed tortor. Integer aliquam adipiscing lacus.', 'S', 8),
(8, 'PIZZA 8', 'Lorem ipsum dolor sit amet,', 'S', 9),
(9, 'PIZZA 9', 'Lorem ipsum dolor sit', 'V', 9),
(10, 'PIZZA 10', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur sed tortor. Integer', 'V', 6),
(11, 'PIZZA 11', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Curabitur', 'V', 6),
(12, 'PIZZA 12', 'Lorem', 'V', 7);

-- --------------------------------------------------------

--
-- Table structure for table `orderlines`
--

CREATE TABLE `orderlines` (
  `orderlineID` int UNSIGNED NOT NULL,
  `orderID` int UNSIGNED NOT NULL,
  `itemID` int UNSIGNED NOT NULL,
  `quantity` tinyint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderID` int UNSIGNED NOT NULL,
  `customerID` int UNSIGNED NOT NULL,
  `extra` varchar(60) DEFAULT NULL,
  `orderdate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`bookingID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerID`);

--
-- Indexes for table `fooditems`
--
ALTER TABLE `fooditems`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `orderlines`
--
ALTER TABLE `orderlines`
  ADD PRIMARY KEY (`orderlineID`),
  ADD KEY `orderID` (`orderID`),
  ADD KEY `itemID` (`itemID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `customerID` (`customerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `bookingID` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerID` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `fooditems`
--
ALTER TABLE `fooditems`
  MODIFY `itemID` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `orderlines`
--
ALTER TABLE `orderlines`
  MODIFY `orderlineID` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderID` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orderlines`
--
ALTER TABLE `orderlines`
  ADD CONSTRAINT `orderlines_ibfk_1` FOREIGN KEY (`orderID`) REFERENCES `orders` (`orderID`),
  ADD CONSTRAINT `orderlines_ibfk_2` FOREIGN KEY (`itemID`) REFERENCES `fooditems` (`itemID`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
