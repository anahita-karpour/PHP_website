<!-- Assumptions:
    -orderline:
        -maximum number of pizza for any pizza is capped at 20 per orderline.
        -if two orderlines each contain the same pizza, only one orderline with that name is saved and the quantity will be added together.
        However, quantity can't be greater than 20. If the addition of two orderlines creates quantity of greater than 20, it will be capped at 20.

        -at least one order line is required and the first row of orderline was chosen to be the required line (can't be null).
    -orderdate input is a required field.
    -orderdate can not be less than "today" or greater than "2023-12-24", and minimum bookable time is "10:00" and maximum bookable time is "21:00",
    
    -Extra input box:
        -is not a required field and can be null
        -maximum text length of 60 and minimum length of 0 (the value can be null) for Extra input box
        -assuming alphanumeric value for the Extra input box with no white spaces is allowed 
            at the start or end
 -->
  <?php
    include "header.php";
    include "checksession.php";
    include "menu.php";
    checkUser();
    ?>
    <div id="body">
    <div class="header">
        <div>
          <h1>Place an order</h1>
        </div>
    </div>
    <?php 
    loginStatus(); 

    include "config.php";   // load in any variables
    
    $DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE) or die();

    // function to clean input but not validate type and content
    function cleanInput($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    // the data was sent using a form therefore we use the $_POST isntead of $_GET
    // check if we are saving data first by checking if the submit button exists in the array
    if(isset($_POST['submit']) and !empty($_POST['submit']) and ($_POST['submit'] == 'Place Order')) {
        // if ($_SERVER["REQUEST_METHOD"] == "POST") { // alternative simpler POST test

        if (mysqli_connect_errno()) {
            echo "Error: Unable to connect to MySQL. ".mysqli_connect_error();
            exit;   // stop processing the page further
        }

        // validate incoming data - only the first field is done for you in this example - rest is up to you to do 
        $id = $_SESSION['customerid'];
        if (empty($id) or !is_numeric($id)){
          echo "<h2>Invalid customer ID</h2>";    // simple error feedback
          exit;
        }
        
        //order-extra
        $error = 0; // clear out error flag
        $msg = 'Error: ';
        if (isset($_POST['extras']) and is_string($_POST['extras'])) {  // we are assuming extra can be left blank
            $ex = cleanInput($_POST['extras']);
            $extra = (strlen($ex) > 61) ? substr($ex, 1, 60):$ex;  // check length and clip if too big
            // we would also do context checking here for contents, etc
        } else {
            $error++;    // bump the error flag
            $msg .= 'Invalid extra  ';    // append error message
            $extra = '';
        }

        //orderdate
        if (isset($_POST['orderdate']) and !empty($_POST['orderdate']) and is_string($_POST['orderdate'])) {
            $od = cleanInput($_POST['orderdate']);
            $orderdate = (strlen($od) > 19) ? substr($od, 1, 19): $od;  // check length and clip if too big
        } else {
            $error++;
            $msg .= 'Invalid orderdate '; // append error message
            $orderdate = '';
        }

        // orderline pizza
        $pizzas = [];
        foreach($_POST['pizza'] as $pizz) {
          if(isset($pizz) and !empty($pizz) and is_integer(intval($pizz))) {
              $pizza = cleanInput($pizz); 
              $pizzas[] = $pizza;

          } else {
              $error++;       // bump the error flag
              $msg .= 'Invalid pizza name '; //append error message
              $pizza = '';
          }          
        }
        
        // orderline quantity
        $qtys = [];
        foreach($_POST['qty'] as $qt) {
          if(isset($qt) and !empty($qt) and is_integer(intval($qt))) {
              $qty = cleanInput($qt);
              if ($qty < 1 or $qty > 20) $qty = 1;
              $qtys[] = $qty;
          } else {
              $error++;   // bump the error flag
              $msg .= 'Invalid pizza quantity! ';
              $qty = '';
          }
        }
        
        // combine the pizza and pizza qty arrays into one.
        // ensuring quantity is added for duplicated keys(pizzas), pizza qty is CAPPED at 20 pizza per pizza name!
        $orderlines = array_unique($pizzas);      
        $orderlines = array_fill_keys($orderlines, 0);    
        
        foreach ($pizzas as $k => $v) {
          if ($orderlines[$v] < 21 && ($orderlines[$v] + $qtys[$k]) < 21) {
              $orderlines[$v] += $qtys[$k];
          } else {
              // enforcing 20 pizza per pizza name                
              $orderlines[$v] = 20;    
          }
      }

      // save the order data if the error flag is still clear
      if ($error == 0) {
          $query1 = "INSERT INTO orders (orders.customerID, orders.orderdate, orders.extra) VALUES (?, ?,?);";                        
          $query2 = "INSERT INTO orderlines (orderlines.orderID, orderlines.itemID, orderlines.quantity) VALUES (?,?,?);";
        
          $stmt1 = mysqli_prepare($DBC,$query1);    // prepare the query         
          mysqli_stmt_bind_param($stmt1, 'iss', $id, $orderdate, $extra);
          mysqli_stmt_execute($stmt1);

          // find the ID of last insert
          $last_row = mysqli_insert_id($DBC);
          // echo($last_row);
          foreach($orderlines as $key => $value) {
            $stmt2 = mysqli_prepare($DBC,$query2);
            // adding orderID, pizza name, pizza qty
            mysqli_stmt_bind_param($stmt2, 'iis', $last_row, $key, $value);            
            mysqli_stmt_execute($stmt2);
          }
          mysqli_stmt_close($stmt1);   
          mysqli_stmt_close($stmt2); 
          echo "<h2>New order added to the list</h2>";   
          
          header('refresh:2; url= listorders.php', true, 303); 

        } else { 
          echo "<h2>$msg</h2>".PHP_EOL;
        }
    }
    $query = 'SELECT fooditems.itemID AS "pizzaNo", fooditems.pizza AS "pizza", fooditems.price 
        FROM fooditems';
      
    $stmt = mysqli_prepare($DBC, $query);      // prepare the quer
    mysqli_stmt_execute($stmt);
    // getting the reslt
    $result = mysqli_stmt_get_result($stmt);
    // returns the number of rows in a result set
    $rowcount = mysqli_num_rows($result);

    if ($rowcount > 0) {      
?>
<div class="body">
  <div>
  <h2>
    <a href="listorders.php">[Return to the Orders listing]</a>
    <a href="index.php">[Return to the main page]</a>
  </h2>
  <h2>Pizza order for <?php echo($_SESSION['firstname'].' '.$_SESSION['lastname']); ?></h2>

  <form method="POST" action="placeorderenhanced.php">
    <p>
      <label for="orderdate">Order for (date & time): </label>
      <input type="datetime-local" id="orderdate" name="orderdate" required>
    </p>
    <p>
      <label for="extras">Extras:</label>
      <input type="text" id="extras" name="extras" value="" maxlength="60" size="50"
        pattern="^[a-zA-Z0-9].[a-zA-Z0-9_\s-]*[a-zA-Z0-9]$">
    </p>
    <hr />
    <table id="tblOrderlines">
      <thead>
        <tr>
          <th colspan="4">Pizzas for this order:</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <label id="pizzaLbl1" for="pizza1"><b>1:</b></label>
          </td>
          <td>
            <select name="pizza[]" id="pizza1" required>
              <option value="">none</option>
              <?php 
                //mysqli_fetch_assoc fetches one row
                while ($row = mysqli_fetch_assoc($result)) {
                  echo "<option value =".$row['pizzaNo'].">".$row['pizza']." @ $".$row['price']."</option>";
                }
              ?>                
            </select>
          </td>
          <td>
            <input type="number" id="qty1" name="qty[]" min="1" max="20" step="1" placeholder="0" class="quantity" required >
          </td>
          <td>
            <input type="button" name="add" value="Add Pizza" id="submit" onclick="addPizza()" >
          </td>
        </tr>
      </tbody>
    </table>
    <input type="submit" name="submit" value="Place Order" id="submit">
    <a href="listorders.php">[Cancel]</a>
  </form>
  <?php
      
    } else {
      echo "<h2>Pizza items not found</h2>";
    }
      mysqli_stmt_free_result($stmt);   // free any memory used by the query
      mysqli_stmt_close($stmt);            
      mysqli_close($DBC);             // close the connection once done   
      echo "</div>";
      echo "</div>"; 
      echo "</div>";

      include "footer.php";
  ?>

  <!-- print order datetime
  <script>
    var orderInput = document.getElementById("orderdate");
    // As a best practice, we do not include the ( ) of the function when setting event handlers in code.
    orderInput.onchange = printValue;

    function printValue() {
      var x = orderInput.value;
      console.log(x);
    } 
  </script>-->

  <!-- flatpickr -->
  <script>
    config = {
      enableTime: true,
      dateFormat: "Y-m-d H:i:S",
      altInput: true,
      altFormat: "Y-m-d H:i",
      allowInput: true, // prevent "readonly"
      //assuming minimum/earliest date of order can be today
      minDate: "today",
      maxDate: "2023.12.25", // not inclusive of this date
      minTime: "10:00",
      maxTime: "21:00",
    };
    flatpickr("#orderdate", config);
  </script>