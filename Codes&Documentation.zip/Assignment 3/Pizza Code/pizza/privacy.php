<?php
include "header.php";
include "checksession.php";

include "menu.php";
?>
		<div id="body">
			<div class="header">
				<div>
					<h1>Privacy Policy</h1>
				</div>
			</div>
			<div class="body">
				<img src="images/bg-header-about.jpg" alt="Pizza">
			</div>
			<div class="footer">
				<div class="sidebar">
					<h1>Be Part of Our Community</h1>
					<p>If you’re experiencing issues or having concerns about this website template, join the discussion on our <a href="/">facebook page</a> and meet other people in the community who share the same interests.</p>
					<img src="images/calzone_sm.jpg" alt="Calzone Pizza">
				</div>
				<div class="article">
					<h1>Privacy Policy</h1>
					<p>We collect personal information from you, including information about your: name and contact information, email and password.</p>
					<p>We collect your personal information in order to allow online booking and ordering of the Pizzeria's food.</p>
					<p>Providing some information is optional. If you choose not to enter your name and email address, we'll be unable to provide online booking and ordering of Pizzeria's food. 
						We keep your information for two years at which point we securely destroy it by securely erasing all digits.</p>
					<p>You have the right to ask for a copy of any personal information we hold about you, and to ask for it to be corrected if you think it is wrong. If you’d like to ask for a copy of your information, or to have it corrected, please contact us at:
                    <span>Email: admin@waipukuraucornerpizzeria.com</span>
                    <span>Tel: 06 858 9000</span>
                    Address: Waipukurau Corner Pizzeria, 1 Main Street, Waipukurau, 4000.</p>
                
                    <img src="images/map.png" alt="Pizzeria Map">
                </div>
			</div>
		</div>
<?php
include "footer.php";
?>
