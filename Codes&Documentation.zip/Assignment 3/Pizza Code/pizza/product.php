<?php
include "header.php";
include "checksession.php";

include "menu.php";
?>
		<div id="body">
			<div class="header">
				<div>
					<h1>Selected Pizzas</h1>
				</div>
			</div>
            
			<div>
				<ul>
					<li>
						<h1>All Time Classic</h1>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean eget lacinia sem. Quisque a libero semper.</p>
					</li>
					<li>
						<img src="images/pizza1.jpg" alt="Pizza1">
						<h2>Pizza 1</h2>
					</li>
					<li>
						<img src="images/pizza2.jpg" alt="Pizza2">
						<h2>Pizza 2</h2>
					</li>
					<li>
						<img src="images/pizza3.jpg" alt="Pizza3">
						<h2>Pizza 3</h2>
					</li>
				</ul>
				<ul>
					<li>
						<h1>Specials</h1>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean eget lacinia sem. Quisque a libero semper.</p>
					</li>
					<li>
						<img src="images/pizza4.jpg" alt="Pizza4">
						<h2>Pizza 4</h2>
					</li>
					<li>
						<img src="images/pizza5.jpg" alt="Pizza5">
						<h2>Pizza 5</h2>
					</li>
					<li>
						<img src="images/pizza6.jpg" alt="Pizza6">
						<h2>Pizza 6</h2>
					</li>
				</ul>
				<ul>
					<li>
						<h1>Meat lovers</h1>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean eget lacinia sem. Quisque a libero semper.</p>
					</li>
					<li>
						<img src="images/pizza7.jpg" alt="Pizza7">
						<h2>Pizza 7</h2>
					</li>
					<li>
						<img src="images/pizza8.jpg" alt="Pizza8">
						<h2>Pizza 8</h2>
					</li>
					<li>
						<img src="images/pizza9.jpg" alt="Pizza9">
						<h2>Pizza 9</h2>
					</li>
				</ul>
			</div>
		</div>
<?php
include "footer.php";
?>