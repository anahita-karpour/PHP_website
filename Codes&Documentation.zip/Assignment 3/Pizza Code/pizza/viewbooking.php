    <?php
    include "header.php";
    include "checksession.php";
    include "menu.php";
    checkUser();
    ?>
    <div id="body">
    <div class="header">
        <div>
        <h1>Booking Details View</h1>
        </div>
    </div>
    <?php 
    loginStatus();
    
    include "config.php"; // load in any variables

    $DBC = mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBDATABASE) or die();

    // insert DB code from here onwards
    // check if the connection was good
    if (mysqli_connect_errno()) {
        echo "Error: Unable to connect to MySQL. " . mysqli_connect_error();
        exit; // stop processing the page further
    }

    // do some simple validation to check if id exists
    $id = $_GET['id'];
    if (empty($id) or !is_numeric($id)) {
        echo "<h2>Invalid booking ID</h2>"; // simple error feedback
        exit;
    }

    // prepare a query and send it to the server
    // use prepared queries when creating custom SQL like below
    $query = 'SELECT bookingdate, customer.firstname, customer.lastname, people, telephone FROM booking 
    INNER JOIN customer on customer.customerID = booking.customerID 
    WHERE bookingID = ?';

    $stmt = mysqli_prepare($DBC, $query);    // prepare the query
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    //Getting the result
    $result = mysqli_stmt_get_result($stmt);
    // returns the number of rows in a result set
    $rowcount = mysqli_num_rows($result);
    ?>


    <div class="body">
        <div>
    <h2>
        <a href='listbookings.php'>[Return to the booking listing]</a>
        <a href='index.php'>[Return to the main page]</a>
    </h2>
    <?php
    //make sure we have the booking item
    if ($rowcount > 0) {
        echo "<fieldset><legend>Booking detail #$id</legend><dl>";
        $row = mysqli_fetch_assoc($result);
        // while ( $row = mysqli_fetch_assoc($result)) {
        echo "<dt>Booking date & time:</dt><dd>".$row['bookingdate']."</dd>".PHP_EOL;
        echo "<dt>Customer name:</dt><dd>".$row['firstname'].", ".$row['lastname']."</dd>".PHP_EOL;
        echo "<dt>Party size:</dt><dd>".$row['people']."</dd>".PHP_EOL;
        echo "<dt>Contact number:</dt><dd>".$row['telephone']."</dd>".PHP_EOL;
        echo "</dl></fieldset>";
    } else echo "<h2>No Booking found!</h2>";    //suitable feedback

    mysqli_free_result($result);    //free any memory used by the query
    mysqli_stmt_close($stmt);
    mysqli_close($DBC);             //close the connection once done

    echo "</div>";
    echo "</div>";
    echo "</div>";
    include "footer.php";
    ?>